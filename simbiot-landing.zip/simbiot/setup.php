<?php
// ================================================================
// setup.php — Inisialisasi database & akun admin pertama
// Jalankan SEKALI, lalu HAPUS file ini dari server.
// ================================================================

require_once __DIR__ . '/config.php';

$error   = '';
$success = false;

function getSetupDB(): PDO {
    $dsn = sprintf('mysql:host=%s;dbname=%s;charset=%s', DB_HOST, DB_NAME, DB_CHARSET);
    return new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
}

// Cek apakah config.php sudah diisi
if (DB_NAME === 'NAMA_DATABASE' || DB_USER === 'NAMA_USER_DB') {
    $error = 'Isi <code>config.php</code> terlebih dahulu sebelum menjalankan setup.';
}

// Cek koneksi & lock
if (!$error) {
    try {
        $db     = getSetupDB();
        $tables = $db->query("SHOW TABLES LIKE 'setup_lock'")->rowCount();
        if ($tables > 0 && $db->query("SELECT id FROM setup_lock LIMIT 1")->rowCount() > 0) {
            die('<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8">
            <style>body{font-family:sans-serif;background:#0A1628;color:#F0F9FF;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
            .box{background:#1E293B;border:1px solid #dc2626;border-radius:12px;padding:2rem;max-width:480px;text-align:center}
            h2{color:#fca5a5;margin-bottom:1rem}code{background:#0A1628;padding:.2rem .5rem;border-radius:4px;color:#38BDF8}
            </style></head><body><div class="box">
            <h2>⛔ Setup sudah dijalankan</h2>
            <p>Hapus file <code>setup.php</code> dari server untuk keamanan.</p>
            </div></body></html>');
        }
    } catch (PDOException $e) {
        $error = 'Koneksi database gagal: <code>' . htmlspecialchars($e->getMessage()) . '</code><br>Pastikan <code>config.php</code> sudah diisi dengan benar.';
    }
}

// Proses form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$error) {
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email']    ?? '');
    $password = $_POST['password']      ?? '';
    $confirm  = $_POST['confirm']       ?? '';

    if (!$username || !$email || !$password) {
        $error = 'Semua field wajib diisi.';
    } elseif (strlen($username) < 3 || !preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $error = 'Username minimal 3 karakter, hanya huruf/angka/underscore.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Format email tidak valid.';
    } elseif (strlen($password) < 8) {
        $error = 'Password minimal 8 karakter.';
    } elseif ($password !== $confirm) {
        $error = 'Konfirmasi password tidak cocok.';
    } else {
        try {
            $db = getSetupDB();

            // Buat tabel users
            $db->exec("CREATE TABLE IF NOT EXISTS `users` (
                `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `username`      VARCHAR(50)  NOT NULL,
                `email`         VARCHAR(100) NOT NULL,
                `password_hash` VARCHAR(255) NOT NULL,
                `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `last_login`    DATETIME     NULL,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_username` (`username`),
                UNIQUE KEY `uq_email`    (`email`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // Buat tabel feedback
            $db->exec("CREATE TABLE IF NOT EXISTS `feedback` (
                `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `name`         VARCHAR(100) NOT NULL,
                `role`         ENUM('siswa','guru','mahasiswa_dosen','pengembang') NOT NULL,
                `message`      TEXT         NOT NULL,
                `response`     TEXT         NULL,
                `status`       ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
                `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `responded_at` DATETIME     NULL,
                PRIMARY KEY (`id`),
                KEY `idx_status`  (`status`),
                KEY `idx_created` (`created_at`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // Buat tabel setup_lock
            $db->exec("CREATE TABLE IF NOT EXISTS `setup_lock` (
                `id`        INT      NOT NULL DEFAULT 1,
                `locked_at` DATETIME NOT NULL,
                PRIMARY KEY (`id`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // Insert admin
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $db->prepare("INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)");
            $stmt->execute([$username, $email, $hash]);

            // Kunci setup
            $db->exec("INSERT IGNORE INTO setup_lock (id, locked_at) VALUES (1, NOW())");

            $success = true;
        } catch (PDOException $e) {
            $error = 'Error database: <code>' . htmlspecialchars($e->getMessage()) . '</code>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Setup — SimbIoT</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: system-ui, -apple-system, sans-serif;
    background: #0A1628; color: #F0F9FF;
    min-height: 100vh; display: flex; align-items: center;
    justify-content: center; padding: 1.5rem;
  }
  .card {
    background: #1E293B; border: 1px solid #2D3D52;
    border-radius: 12px; padding: 2rem; width: 100%; max-width: 440px;
  }
  .logo { font-size: 1.4rem; font-weight: 700; margin-bottom: 0.25rem; }
  .logo span { color: #0D9488; }
  .sub { color: #64748B; font-size: 0.83rem; margin-bottom: 1.75rem; }
  label { display: block; font-size: 0.83rem; color: #94A3B8; margin-bottom: 0.35rem; font-weight: 500; }
  input {
    width: 100%; background: #0A1628; border: 1px solid #2D3D52;
    color: #F0F9FF; padding: 0.625rem 0.875rem; border-radius: 8px;
    font-size: 0.93rem; margin-bottom: 1rem; outline: none; transition: border-color 0.2s;
  }
  input:focus { border-color: #0D9488; }
  button {
    width: 100%; background: #0D9488; color: #fff; border: none;
    padding: 0.75rem; border-radius: 8px; font-size: 1rem;
    cursor: pointer; font-weight: 600; transition: background 0.2s;
  }
  button:hover { background: #0f766e; }
  .alert { padding: 0.75rem 1rem; border-radius: 8px; margin-bottom: 1.25rem; font-size: 0.875rem; line-height: 1.6; }
  .alert-error { background: #451a1a; border: 1px solid #dc2626; color: #fca5a5; }
  .alert-success { background: #0d3321; border: 1px solid #16a34a; color: #86efac; }
  .alert-success h3 { margin-bottom: 0.5rem; font-size: 1rem; }
  .alert-warn { background: #431407; border: 1px solid #ea580c; color: #fdba74; margin-top: 1rem; }
  code { background: #0A1628; padding: 0.1rem 0.4rem; border-radius: 4px; font-size: 0.85em; color: #38BDF8; }
  a { color: #38BDF8; }
  hr { border: none; border-top: 1px solid #2D3D52; margin: 1.25rem 0; }
</style>
</head>
<body>
<div class="card">
  <div class="logo">Simb<span>IoT</span></div>
  <p class="sub">Setup awal — buat tabel database & akun admin pertama</p>

  <?php if ($success): ?>
    <div class="alert alert-success">
      <h3>✅ Setup berhasil!</h3>
      <p>Tabel database berhasil dibuat. Akun admin sudah siap digunakan.</p>
      <hr style="border-color:#16a34a;margin:.75rem 0">
      <p>Login admin: <a href="/admin/login.php">/admin/login.php</a></p>
    </div>
    <div class="alert alert-warn">
      ⚠️ <strong>Segera hapus file <code>setup.php</code> dari server!</strong><br>
      File ini tidak boleh bisa diakses setelah setup selesai.
    </div>
  <?php else: ?>
    <?php if ($error): ?>
      <div class="alert alert-error">⚠️ <?= $error ?></div>
    <?php endif; ?>
    <form method="POST" autocomplete="off">
      <label for="u-username">Username Admin</label>
      <input type="text" id="u-username" name="username"
             value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
             placeholder="contoh: benny" autocomplete="off" required>

      <label for="u-email">Email</label>
      <input type="email" id="u-email" name="email"
             value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
             placeholder="admin@simbiot.id" required>

      <label for="u-pass">Password <span style="color:#64748B;font-weight:400">(min. 8 karakter)</span></label>
      <input type="password" id="u-pass" name="password" placeholder="••••••••" required>

      <label for="u-confirm">Konfirmasi Password</label>
      <input type="password" id="u-confirm" name="confirm" placeholder="••••••••" required>

      <button type="submit">Buat Akun & Inisialisasi Database</button>
    </form>
  <?php endif; ?>
</div>
</body>
</html>
