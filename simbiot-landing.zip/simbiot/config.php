<?php
// ================================================================
// config.php — Konfigurasi SimbIoT Platform
// ================================================================
// PENTING: Isi semua nilai di bawah sesuai data cPanel kamu.
//          Jangan upload file ini ke repository publik.
// ================================================================

// --- Database ---
define('DB_HOST',    'localhost');
define('DB_NAME',    'NAMA_DATABASE');   // ← ganti
define('DB_USER',    'NAMA_USER_DB');    // ← ganti
define('DB_PASS',    'PASSWORD_DB');     // ← ganti
define('DB_CHARSET', 'utf8mb4');

// --- Aplikasi ---
define('APP_NAME', 'SimbIoT');
define('APP_URL',  'https://simbiot.id');

// --- Session Admin ---
define('SESSION_NAME',     'simbiot_sess');
define('SESSION_LIFETIME', 7200); // 2 jam dalam detik
