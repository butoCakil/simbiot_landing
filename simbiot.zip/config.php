<?php
// ================================================================
// config.php — Konfigurasi SimbIoT Platform
// ================================================================
// PENTING: Isi semua nilai di bawah sesuai data cPanel kamu.
//          Jangan upload file ini ke repository publik.
// ================================================================

// --- Database ---
define('DB_HOST',    'localhost');
define('DB_NAME',    'dvttaulx_simbiot_page');   // ← ganti
define('DB_USER',    'dvttaulx_default_user');    // ← ganti
define('DB_PASS',    'cM_WcSBw[#8QZ0A-');     // ← ganti
// define('DB_USER',    'dvttaulx_masbendz');    // ← ganti
// define('DB_PASS',    'gk#F!X{gYTdxsD]Z');     // ← ganti
define('DB_CHARSET', 'utf8mb4');

// --- Aplikasi ---
define('APP_NAME', 'SimbIoT');
define('APP_URL',  'https://simbiot.id');

// --- Session Admin ---
define('SESSION_NAME',     'simbiot_sess');
define('SESSION_LIFETIME', 7200); // 2 jam dalam detik
